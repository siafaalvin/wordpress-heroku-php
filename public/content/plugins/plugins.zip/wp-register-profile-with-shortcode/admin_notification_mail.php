<?php

// Registration mail to admin //
// This mail will be sent to admin when new user make registration in the site. //

// mail subject 
// Please update mail subject if you want //
$wprw_mail_to_admin_subject = 'New User Registration';
// mail subject 

// mail body //
// Please update mail body if you want //
$wprw_mail_to_admin_body = 'New user registration on your site #site_name#
<br><br>
<h3>New User Data</h3>
<br>
#new_user_data#
<br><br>';
// mail body //

// Registration mail to admin //